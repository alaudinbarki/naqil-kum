   import 'package:flutter/material.dart';

const Color blueColor = Color(0xff28476E);
    const Color lightblueColor = Color(0xff5473C1);
    const Color headerColor = Color(0xffB9BEC9);
   const Color orderStatus1Color = Color(0xff286A6E);
   const Color orderStatus2Color = Color(0xff6E4F28);
   const Color orderStatus3Color = Color(0xff286E4F);
   const Color myChatColor = Color(0xff28476E);
   const Color yourChatColor = Color(0xff4174B4);